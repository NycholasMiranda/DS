
package ListaCondiçãoJava;

import java.util.Scanner;

public class Ex3Java {

    
    public static void main(String[] args) {
        
        double nota1, nota2, media;
        
        String nome;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira o seu nome: ");
        nome = teclado.next();
        
        System.out.println("Insira sua primeira nota: ");
        nota1 = teclado.nextDouble();
        
        System.out.println("Insira sua segunda nota: ");
        nota2 = teclado.nextDouble();
        
        media = (nota1 + nota2)/2;
        
        if (media > 0 && media <= 3.99)
        {
            System.out.println("Nome: " +nome+  "\n" + "Media: " +media+ "\n" + "Situacao: Reprovado");
        }
       
           
        if (media > 4 && media <= 5.99)
            {
                 System.out.println("Nome: " +nome+  "\n" + "Media: " +media+ "\n" + "Situacao: Recuperacao");
             }
        
        
        if(media > 6 && media <=10)    
        {
            System.out.println("Nome: " +nome+  "\n" + "Media: " +media+ "\n" + "Situacao: Aprovado");
        }
                     
        
        
        
    }
    
}
