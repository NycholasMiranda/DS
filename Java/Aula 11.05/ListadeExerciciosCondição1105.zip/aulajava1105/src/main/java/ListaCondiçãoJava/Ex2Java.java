
package ListaCondiçãoJava;

import java.util.Scanner;

public class Ex2Java {

   
    public static void main(String[] args) {
        
        int ano;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira um ano: ");
        ano = teclado.nextInt();
        
        if(ano <2020)
        {
            System.out.println(+ano+ " " + "e do passado");
            
        }
        
         if(ano>2020)
                    {
                        System.out.println(+ano+ " " + "e do futuro"); 
                        
                    }
        
        
        if(ano == 2020)
        {
            System.out.println(+ano+ " " + "e o ano atual");
        }
        
        
    }
    
}
