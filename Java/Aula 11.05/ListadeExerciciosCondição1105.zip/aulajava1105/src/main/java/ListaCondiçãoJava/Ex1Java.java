
package ListaCondiçãoJava;

import java.util.Scanner;


public class Ex1Java {

    
    public static void main(String[] args) {
        
        double numero;
                
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira um numero: ");
        numero = teclado.nextDouble();
        
        
        
        
        
        if(numero%2==0)
        {
            System.out.println("O numero e par");
                   
        }
        
        else
        {
            System.out.println("O numero e impar");
            
        }
        
    }
    
}
