
public class Atividade2206 {

 
        
                
  public static void main(String[] args) {
    
     int vetor[] = new int [10]; 
        
              
                vetor[0] = 2;
                vetor[1] = 4;
                vetor[2] = 5;
                vetor[3] = 6;
                vetor[4] = 8;
                vetor[5] = 10;
                vetor[6] = 12;
                vetor[7] = 14;
                vetor[8] = 16;
                vetor[9] = 18;
      
      
for (int i = 0; i < vetor.length; i++) {
          
          System.out.println(vetor[i]);
          
      }
      
      System.out.println("\n");
      System.out.println("----------------");
      System.out.println("\n");

      vetor[4] = 87;
      vetor[2] = 27;
      
      for (int i = 0; i < vetor.length; i++) {
          
          System.out.println(vetor[i]);
          
      }
                
                
        
    }
    
}
