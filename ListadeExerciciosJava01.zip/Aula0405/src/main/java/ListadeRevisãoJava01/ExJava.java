
package ListadeRevisãoJava01;

import java.util.Scanner;

public class ExJava {

    
   
    public static void main(String[] args) {
        
        String nome;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira seu nome: ");
        nome = teclado.next();
        
        System.out.println("ola" + " " +nome+ " " + "seja bem vindo");
       
        
        
        
       
    }
    
}
