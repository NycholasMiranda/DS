
package ListadeRevisãoJava01;

import java.util.Scanner;

public class Ex5Java {


    public static void main(String[] args) {
        
        //tinham dois Ex 4 então eu coloquei esse como Ex 5
        
        double km, milhas;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira a quantidade de quilometros que voce quer converter para milhas: ");
        km = teclado.nextDouble();
        
        milhas = km / 1.60934;
        
        System.out.println( +km+ " km em milhas e igual a " +milhas);
        
        
        
       
        
        
        
        
        
        
        
    }
    
}
