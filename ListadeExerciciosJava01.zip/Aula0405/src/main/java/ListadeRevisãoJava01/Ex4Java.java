
package ListadeRevisãoJava01;

import java.util.Scanner;

public class Ex4Java {

    
    public static void main(String[] args) {
        
        double baset, alturat, areat, ladoq, areaq, altura, peso, imc;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Calcular area do triangulo \n");
        
        System.out.println("Insira a base do triangulo: ");
        baset = teclado.nextDouble();
        
        System.out.println("Insira a altura do triangulo: ");
        alturat = teclado.nextDouble();
        
        areat = (baset * alturat)/2;
        
        System.out.println("A area do triangulo e: " +areat);
        
       
        System.out.println("----------------------------");
        
        System.out.println("Calcular area de quadrado \n");
        
        System.out.println("Insira o lado do quadrado: ");
        ladoq = teclado.nextDouble();
        
       areaq = Math.pow(ladoq, 2);
        
        System.out.println("A area do quadrado e: " +areaq);
        
         System.out.println("----------------------------");
         
         System.out.println("Calcular o seu IMC");
         
         System.out.println("Insira o seu peso (em kg): ");
         peso = teclado.nextDouble();
         
         System.out.println("Insira a sua altura (em metros): ");
         altura = teclado.nextDouble();
         
         imc = peso / Math.pow(altura, 2);
         
         System.out.println("Seu IMC e: " +imc);
         
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
