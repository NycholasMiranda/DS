
package ListadeRevisãoJava01;

import java.util.Scanner;

public class Ex6Java {

    
    public static void main(String[] args) {
        
        int meses, dias;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira a quantidade de meses que deseja converter para dias: ");
        meses = teclado.nextInt();
        
        dias = meses * 30;
        
        System.out.println("O número de dias convertidos de meses e igual a: " +dias);
        
        
    }
    
}
