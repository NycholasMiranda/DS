
package ListadeRevisãoJava01;

import java.util.Scanner;

public class Ex3Java {

    
    public static void main(String[] args) {
        
        int numero = 1;
        int numero2 = 1;
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira um numero: ");
        numero = teclado.nextInt();
        
        while (numero2 > 0 && numero2 <= 10)
        {
            
            System.out.println(numero + " x " + numero2 + " = " + numero2 * numero );
numero2++;
        }
       
    }
    
}
