
package ListadeRevisãoJava01;

import java.util.Scanner;

public class Ex2Java {



        public static void main(String[] args) {
        
        double nota1, nota2, nota3, nota4, mediafinal;
        
        String nome; 
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Insira seu nome: ");
        nome = teclado.next();
            
        
        System.out.println("Insira sua primeira nota: ");
        nota1 = teclado.nextDouble(); 
        
        
        
        System.out.println("Insira sua segunda nota nota: ");
        nota2 = teclado.nextDouble();
        
        
        System.out.println("Insira sua terceira nota: ");
        nota3 = teclado.nextDouble();
        
        
        System.out.println("Insira sua quarta nota: ");
        nota4 = teclado.nextDouble();
        
        
        mediafinal = (nota1 + nota2 + nota3 + nota4)/2;
        
        System.out.println("Ola" + " " +nome+ " " + "sua media final e: " +mediafinal);
        
        
        
        
    }
    
}
